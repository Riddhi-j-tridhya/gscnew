=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://www.quanticedgesolutions.com
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows the branch management for GSC Bank.

== Description ==

This plugin allows the branch management for GSC Bank.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `gsc-bank-branch-management.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Changelog ==

= 1.0 =
* Initial release.